# KIRA OS — аудит зависимостей

Статический анализ исходников и build scripts. Он не заменяет бинарный анализ ISO/KiraFS и security review.

- Tracked files: 1154; production C/ASM/header files scanned: 469.
- OS build linker -l flags: 1; host-test-only linker flags: 2 (m, pthread); library-file candidates: 0.
- Git submodules: no; vendor directories: 0.
- Freestanding/no-libc evidence in build flags: not confirmed.

## Components and tools

| Component | Classification |
|---|---|
| GRUB 2 / Multiboot2 | Bundled in x86 ISO; external boot-chain dependency |
| Shared/static library files | No tracked library files detected; binary image scan still required |
| CA roots | Host CA bundle copied to /etc/ssl/roots.der (trust data) |
| clang | build-time compiler |
| ld.lld | build-time linker |
| nasm | build-time x86 assembler |
| wasm-ld | build-time WebAssembly linker |
| llvm-objcopy | build-time ARM image converter |
| grub-mkrescue | build-time ISO tool; GRUB itself is included in the ISO |
| xorriso | build-time ISO authoring tool |
| qemu-system-x86_64 | test-only virtual x86 machine |
| qemu-system-aarch64 | test-only virtual ARM machine |
| qemu-system-arm | test-only virtual ARM machine |
| gcc | host-side build/test compiler |
| python3 | CI/test orchestration |
| openssl | test oracle, not an OS library |
| python3-cryptography | test oracle, not an OS library |
| python3-pil | test image helper, not an OS library |
| dosfstools | host-side FAT test utility |
| mtools | host-side FAT image utility |
| ca-certificates | trust-root data copied to the system disk |
| KVM | host acceleration for QEMU tests; not shipped in the OS image |

## Source provenance markers

- kcc/include/bsd/bsd_core.h:4: /* Слой совместимости с драйверным API OpenBSD для драйверов Ring 3 Киры (docs/BSD_COMPAT.md). Все заголовки <sys/...>, <net/...>, <machine/...>,
- kcc/include/kdrv_bsd.h:4: /* Слой совместимости для портов BSD-драйверов (FreeBSD, OpenBSD, NetBSD) в драйвер Ring 3 Киры. Не вся ядерная часть BSD, а ровно то,
- userland/bsd_rt.c:2: опрашивает «прерывания» (INTx для Ring 3 нет), таймеры и кольцо передачи ядра; всё остальное - обычный код драйвера из корпуса OpenBSD.
- userland/bsd_rt.c:261: /* ---- MII: один общий PHY IEEE 802.3 (как ukphy в OpenBSD). Находит первый отвечающий адрес, автосогласование, состояние связи. Особенностей
- userland/drvget_core.c:333: /* Короткая разрешительная лицензия Дэвида Гринмана (dp8390, ne2000 в OpenBSD/NetBSD): использование, изменение, копирование, распространение и продажа
- userland/kdrv_bsd.h:4: /* Слой совместимости для портов BSD-драйверов (FreeBSD, OpenBSD, NetBSD) в драйвер Ring 3 Киры. Не вся ядерная часть BSD, а ровно то,

## Remaining independence/security blockers

- Replace GRUB/Multiboot2 with KIRA's own BIOS and UEFI loader.
- kcc supports a C subset; full build still uses external Clang/LLD/NASM and wasm-ld.
- RTL8139 rl(4) is a BSD-attributed port based on FreeBSD driver behavior; a specification-based rewrite is required for a strict all-original-code policy.
- SHA-256 alone does not authenticate package publishers; add signed manifests, trusted keys and anti-rollback checks.
- DMA-capable drivers need IOMMU domains or DMA must be disabled for untrusted drivers.
- QEMU results do not validate physical x86/ARM hardware.

## Scanner limits

- Include resolution and linker flags are heuristic; generated headers and compiler-provided headers are classified separately.
- Host-test linker flags and tools are inventoried separately; they are not linked into the OS image.
- The script does not unpack final ISO or KiraFS images. Run a binary-level audit on the produced artifacts before release.
- Provenance markers require human review; they are not a license verdict.
