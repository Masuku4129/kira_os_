# KIRA OS v46 — CI test report

Commit: fc050446d03a4c7c37bcabe750c4e9512507a31e
Branch: v46/unified-release-integration
Run: https://github.com/Masuku4129/kira_os_/actions/runs/42476924686

| Required job | Result |
|---|---|
| Host tests | success |
| x86_64 build | success |
| x86_64 QEMU matrix | success |
| ARM64 build and QEMU | success |
| Static dependency/source audit | success |
| Mind quality (ASan/UBSan) | success |
| GUI regression | success |
| KCC compiler suite | success |
| Driver installer E2E | success |
| UEFI OVMF boot | success |
| Binary ISO/KiraFS audit | success |

## QEMU scenario evidence

| Scenario | Result | Seconds | Evidence | Detail |
|---|---|---:|---|---|
| arm64-cc | PASS | 13.2 | vm-arm64/arm64-cc/result.json | — |
| arm64-crash | PASS | 4.5 | vm-arm64/arm64-crash/result.json | — |
| arm64-dma-nc | PASS | 9.6 | vm-arm64/arm64-dma-nc/result.json | — |
| arm64-drv | PASS | 18.0 | vm-arm64/arm64-drv/result.json | — |
| arm64-drvman | PASS | 38.7 | vm-arm64/arm64-drvman/result.json | — |
| arm64-el2-8cpu | PASS | 1.8 | vm-arm64/arm64-el2-8cpu/result.json | — |
| arm64-explorer2 | PASS | 31.3 | vm-arm64/arm64-explorer2/result.json | — |
| arm64-fault | PASS | 1.5 | vm-arm64/arm64-fault/result.json | — |
| arm64-gicv2 | PASS | 18.4 | vm-arm64/arm64-gicv2/result.json | — |
| arm64-gicv3 | PASS | 27.3 | vm-arm64/arm64-gicv3/result.json | — |
| arm64-gui | PASS | 50.3 | vm-arm64/arm64-gui/result.json | — |
| arm64-isolation | PASS | 14.9 | vm-arm64/arm64-isolation/result.json | — |
| arm64-overflow | PASS | 1.6 | vm-arm64/arm64-overflow/result.json | — |
| arm64-power | PASS | 6.0 | vm-arm64/arm64-power/result.json | — |
| arm64-ramfb | PASS | 4.2 | vm-arm64/arm64-ramfb/result.json | — |
| arm64-usb | PASS | 10.0 | vm-arm64/arm64-usb/result.json | — |
| apps-explorer2 | PASS | 33.8 | vm-shard-0/apps-explorer2/result.json | — |
| boot-virtio | PASS | 15.3 | vm-shard-0/boot-virtio/result.json | — |
| net-ipv6 | PASS | 35.0 | vm-shard-0/net-ipv6/result.json | — |
| usb-uhci | PASS | 12.7 | vm-shard-0/usb-uhci/result.json | — |
| apps-view | PASS | 55.0 | vm-shard-1/apps-view/result.json | — |
| boot-ata | PASS | 10.1 | vm-shard-1/boot-ata/result.json | — |
| sound-sb16 | PASS | 15.6 | vm-shard-1/sound-sb16/result.json | — |
| stress-spam | PASS | 28.5 | vm-shard-1/stress-spam/result.json | — |
| boot-sata | PASS | 12.2 | vm-shard-2/boot-sata/result.json | — |
| mind-levers | PASS | 206.1 | vm-shard-2/mind-levers/result.json | — |
| net-virtio | PASS | 109.5 | vm-shard-2/net-virtio/result.json | — |
| stress-spam-2 | PASS | 28.6 | vm-shard-2/stress-spam-2/result.json | — |
| apps-wasm | PASS | 48.5 | vm-shard-3/apps-wasm/result.json | — |
| boot-nvme | PASS | 12.2 | vm-shard-3/boot-nvme/result.json | — |
| mind-seed | PASS | 13.2 | vm-shard-3/mind-seed/result.json | — |
| stress-spam-4 | PASS | 28.8 | vm-shard-3/stress-spam-4/result.json | — |
| boot-1cpu | PASS | 10.2 | vm-shard-4/boot-1cpu/result.json | — |
| cc-native | PASS | 75.6 | vm-shard-4/cc-native/result.json | — |
| stress-3d | PASS | 19.3 | vm-shard-4/stress-3d/result.json | — |
| wasm-speed | PASS | 13.6 | vm-shard-4/wasm-speed/result.json | — |
| boot-8cpu | PASS | 10.4 | vm-shard-5/boot-8cpu/result.json | — |
| drv-edu | PASS | 33.0 | vm-shard-5/drv-edu/result.json | — |
| limbo-spam | PASS | 38.8 | vm-shard-5/limbo-spam/result.json | — |
| power-off | PASS | 7.1 | vm-shard-5/power-off/result.json | — |
| drvget-rl | PASS | 57.1 | vm-shard-6/drvget-rl/result.json | — |
| limbo-mttcg | PASS | 38.3 | vm-shard-6/limbo-mttcg/result.json | — |
| power-reboot | PASS | 15.6 | vm-shard-6/power-reboot/result.json | — |
| soak-8cpu | PASS | 39.3 | vm-shard-6/soak-8cpu/result.json | — |
| crash-isolation | PASS | 20.1 | vm-shard-7/crash-isolation/result.json | — |
| drvman-edu | PASS | 37.8 | vm-shard-7/drvman-edu/result.json | — |
| isolation | PASS | 50.3 | vm-shard-7/isolation/result.json | — |
| net-e1000 | PASS | 25.0 | vm-shard-7/net-e1000/result.json | — |
| apps-drvman | PASS | 47.1 | vm-shard-8/apps-drvman/result.json | — |
| net-e1000e | PASS | 19.3 | vm-shard-8/net-e1000e/result.json | — |
| smp | PASS | 23.4 | vm-shard-8/smp/result.json | — |
| sound-hda | PASS | 30.5 | vm-shard-8/sound-hda/result.json | — |
| apps-edit | PASS | 15.4 | vm-shard-9/apps-edit/result.json | — |
| drvman-quiet | PASS | 17.2 | vm-shard-9/drvman-quiet/result.json | — |
| sound-ac97 | PASS | 16.7 | vm-shard-9/sound-ac97/result.json | — |
| usb-xhci | PASS | 15.0 | vm-shard-9/usb-xhci/result.json | — |

Result JSON files: 56; ARM64 result files: 16.

## Captured logs

- Host tests: vm-host-tests/host-tests.log
- Mind quality: mind-quality/mind-quality.log
- GUI regression: gui-regression/gui-regression.log
- KCC compiler suite: kcc-tests/kcc-tests.log
- Driver installer E2E: driver-e2e/driver-e2e.log
- UEFI OVMF serial: ../uefi-ovmf/serial.log

## Scope limits

- QEMU is virtual-hardware evidence only; physical x86_64/ARM64 hardware remains untested.
- A successful static audit is not proof of memory safety or complete dependency absence.
- SHA-256 checksums do not authenticate the publisher.
