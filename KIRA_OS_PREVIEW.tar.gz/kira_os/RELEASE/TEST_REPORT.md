# KIRA OS v46 — CI test report

Commit: 8bfd6457a44f5546bb7f3357ee3da46d42bbfc2e
Branch: autodrv
Run: https://github.com/Masuku4129/kira_os_/actions/runs/43697388854

| Required job | Result |
|---|---|
| Host tests | success |
| x86_64 build | success |
| x86_64 QEMU matrix | success |
| ARM64 build and QEMU | success |
| Static dependency/source audit | success |
| Mind quality (ASan/UBSan) | success |
| GUI regression | success |
| KCC compiler suite | success |
| Driver installer E2E | success |
| UEFI OVMF boot | success |
| Binary ISO/KiraFS audit | success |

## QEMU scenario evidence

| Scenario | Result | Seconds | Evidence | Detail |
|---|---|---:|---|---|
| arm64-cc | PASS | 13.3 | vm-arm64/arm64-cc/result.json | — |
| arm64-crash | PASS | 4.5 | vm-arm64/arm64-crash/result.json | — |
| arm64-dma-nc | PASS | 9.7 | vm-arm64/arm64-dma-nc/result.json | — |
| arm64-drv | PASS | 18.0 | vm-arm64/arm64-drv/result.json | — |
| arm64-drvman | PASS | 38.5 | vm-arm64/arm64-drvman/result.json | — |
| arm64-el2-8cpu | PASS | 1.9 | vm-arm64/arm64-el2-8cpu/result.json | — |
| arm64-explorer2 | PASS | 30.9 | vm-arm64/arm64-explorer2/result.json | — |
| arm64-fault | PASS | 1.5 | vm-arm64/arm64-fault/result.json | — |
| arm64-gicv2 | PASS | 18.1 | vm-arm64/arm64-gicv2/result.json | — |
| arm64-gicv3 | PASS | 27.5 | vm-arm64/arm64-gicv3/result.json | — |
| arm64-gui | PASS | 50.3 | vm-arm64/arm64-gui/result.json | — |
| arm64-isolation | PASS | 14.9 | vm-arm64/arm64-isolation/result.json | — |
| arm64-overflow | PASS | 1.6 | vm-arm64/arm64-overflow/result.json | — |
| arm64-power | PASS | 5.9 | vm-arm64/arm64-power/result.json | — |
| arm64-ramfb | PASS | 4.3 | vm-arm64/arm64-ramfb/result.json | — |
| arm64-usb | PASS | 10.1 | vm-arm64/arm64-usb/result.json | — |
| apps-explorer2 | PASS | 30.4 | vm-shard-0/apps-explorer2/result.json | — |
| boot-virtio | PASS | 12.6 | vm-shard-0/boot-virtio/result.json | — |
| drv-io | PASS | 10.9 | vm-shard-0/drv-io/result.json | — |
| net-ipv6 | PASS | 32.1 | vm-shard-0/net-ipv6/result.json | — |
| usb-uhci | PASS | 9.6 | vm-shard-0/usb-uhci/result.json | — |
| apps-view | PASS | 51.7 | vm-shard-1/apps-view/result.json | — |
| boot-ata | PASS | 6.8 | vm-shard-1/boot-ata/result.json | — |
| drv-bsd-ne2k | PASS | 30.5 | vm-shard-1/drv-bsd-ne2k/result.json | — |
| sound-sb16 | PASS | 12.7 | vm-shard-1/sound-sb16/result.json | — |
| stress-spam | PASS | 26.1 | vm-shard-1/stress-spam/result.json | — |
| boot-sata | PASS | 8.7 | vm-shard-2/boot-sata/result.json | — |
| drv-bsd-pcn | PASS | 20.8 | vm-shard-2/drv-bsd-pcn/result.json | — |
| mind-levers | PASS | 202.9 | vm-shard-2/mind-levers/result.json | — |
| net-virtio | PASS | 106.3 | vm-shard-2/net-virtio/result.json | — |
| stress-spam-2 | PASS | 25.1 | vm-shard-2/stress-spam-2/result.json | — |
| apps-wasm | PASS | 45.2 | vm-shard-3/apps-wasm/result.json | — |
| boot-nvme | PASS | 8.3 | vm-shard-3/boot-nvme/result.json | — |
| drv-bsd-fxp | PASS | 20.7 | vm-shard-3/drv-bsd-fxp/result.json | — |
| mind-seed | PASS | 9.6 | vm-shard-3/mind-seed/result.json | — |
| stress-spam-4 | PASS | 24.9 | vm-shard-3/stress-spam-4/result.json | — |
| boot-1cpu | PASS | 7.3 | vm-shard-4/boot-1cpu/result.json | — |
| cc-native | PASS | 72.7 | vm-shard-4/cc-native/result.json | — |
| drv-bsd-dc | PASS | 21.1 | vm-shard-4/drv-bsd-dc/result.json | — |
| stress-3d | PASS | 15.9 | vm-shard-4/stress-3d/result.json | — |
| wasm-speed | PASS | 10.5 | vm-shard-4/wasm-speed/result.json | — |
| boot-8cpu | PASS | 6.8 | vm-shard-5/boot-8cpu/result.json | — |
| drv-edu | PASS | 29.7 | vm-shard-5/drv-edu/result.json | — |
| limbo-spam | PASS | 35.7 | vm-shard-5/limbo-spam/result.json | — |
| power-off | PASS | 3.8 | vm-shard-5/power-off/result.json | — |
| drvget-rl | PASS | 49.8 | vm-shard-6/drvget-rl/result.json | — |
| limbo-mttcg | PASS | 34.1 | vm-shard-6/limbo-mttcg/result.json | — |
| power-reboot | PASS | 8.5 | vm-shard-6/power-reboot/result.json | — |
| soak-8cpu | PASS | 35.8 | vm-shard-6/soak-8cpu/result.json | — |
| boot-bios | PASS | 8.9 | vm-shard-7/boot-bios/result.json | — |
| crash-isolation | PASS | 16.8 | vm-shard-7/crash-isolation/result.json | — |
| drvman-edu | PASS | 35.1 | vm-shard-7/drvman-edu/result.json | — |
| isolation | PASS | 46.8 | vm-shard-7/isolation/result.json | — |
| net-e1000 | PASS | 21.6 | vm-shard-7/net-e1000/result.json | — |
| apps-drvman | PASS | 43.7 | vm-shard-8/apps-drvman/result.json | — |
| boot-grub | PASS | 12.3 | vm-shard-8/boot-grub/result.json | — |
| net-e1000e | PASS | 15.9 | vm-shard-8/net-e1000e/result.json | — |
| smp | PASS | 20.0 | vm-shard-8/smp/result.json | — |
| sound-hda | PASS | 27.3 | vm-shard-8/sound-hda/result.json | — |
| apps-edit | PASS | 12.7 | vm-shard-9/apps-edit/result.json | — |
| drvman-quiet | PASS | 14.5 | vm-shard-9/drvman-quiet/result.json | — |
| sound-ac97 | PASS | 14.1 | vm-shard-9/sound-ac97/result.json | — |
| usb-xhci | PASS | 12.4 | vm-shard-9/usb-xhci/result.json | — |

Result JSON files: 63; ARM64 result files: 16.

## Captured logs

- Host tests: vm-host-tests/host-tests.log
- Mind quality: mind-quality/mind-quality.log
- GUI regression: gui-regression/gui-regression.log
- KCC compiler suite: kcc-tests/kcc-tests.log
- Driver installer E2E: driver-e2e/driver-e2e.log
- UEFI OVMF serial: ../uefi-ovmf/serial.log

## Scope limits

- QEMU is virtual-hardware evidence only; physical x86_64/ARM64 hardware remains untested.
- A successful static audit is not proof of memory safety or complete dependency absence.
- SHA-256 checksums do not authenticate the publisher.
