#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
sha256sum -c RELEASE/SHA256SUMS
for f in build_clang.sh build_arm64.sh grub.cfg arch/x86_64/linker.ld arch/aarch64/linker.ld drivers/index.txt ci/dependency_audit.py docs/DEPENDENCIES.md docs/DRIVERS.md docs/KCC.md docs/V44_UPGRADE_PLAN.md docs/V44_SECURITY_MODEL.md; do
  test -f "$f" || { echo "missing required file: $f" >&2; exit 1; }
done
echo "KIRA OS v46 source archive: verified"
