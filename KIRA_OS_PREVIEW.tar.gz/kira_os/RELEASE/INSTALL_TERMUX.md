# Установка KIRA OS v46 на Android (Termux/Debian)

**ТЕСТОВАЯ СБОРКА, не релиз** (см. PREVIEW_NOT_RELEASE.txt).

Архив содержит исходники и **готовые образы, собранные и проверенные тем же CI run**:
- `RELEASE/kira.iso` — готовый x86-64 ISO;
- `RELEASE/kira_disk.img` — системный диск, собранный тем же CI run;
- `RELEASE/kira-arm64.img` и `RELEASE/kira-arm64.disk` — ARM64 артефакты, если они были собраны.

1. Распаковать архив из Download:
   `mkdir -p ~/kira_os && tar -xzf /storage/emulated/0/Download/KIRA_OS_PREVIEW.tar.gz -C ~`
2. Перейти в проект и проверить контрольные суммы:
   `cd ~/kira_os && bash RELEASE/VERIFY.sh`
3. Установить готовый ISO в Android Download:
   `cp -f RELEASE/kira.iso /storage/emulated/0/Download/kira.iso`
4. Если системного диска ещё нет, создать его из поставленного образа:
   `test -e /storage/emulated/0/Download/kira_disk.img || cp RELEASE/kira_disk.img /storage/emulated/0/Download/kira_disk.img`

**Важно:** существующий `kira_disk.img` не перезаписывается этой инструкцией, чтобы не потерять пользовательские файлы и опыт Mind. Для обновления системных файлов на уже существующем диске после резервного копирования используйте из каталога проекта `./build_clang.sh --android`; этот путь собирает образ и обновляет существующий диск по логике build script.

Для Limbo: CD-ROM = `kira.iso`, Hard Disk A = `kira_disk.img`, Boot from = CD-ROM. Перед проверкой убедитесь, что Limbo использует именно скопированный ISO.

SHA-256 архива проверяйте командой `sha256sum -c KIRA_OS_PREVIEW.tar.gz.sha256` из каталога Download.
