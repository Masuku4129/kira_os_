#ifndef KIRA_KDRV_H
#define KIRA_KDRV_H
#include <stdint.h>
#include <stddef.h>

/* Менеджер драйверов Ring 3 (drvd): устройства PCI без встроенного драйвера получают процесс drv-ИМЯ из пакета /drv/ИМЯ.kdrv.
   Формат пакета и договор с драйвером - kdrv_format.h, устройство проекта - docs/DRIVERS.md.
   Безопасность: драйвер видит только СВОЁ устройство (его BAR, конфигурацию, прерывание, свою DMA-память); права проверяет ядро
   (caps.h + привязка процесса к устройству); SHA-256 пакета сверяется с /drv/ИМЯ.rec при каждой загрузке; при гибели драйвера
   устройство останавливается (bus master, память, MSI выключены), DMA и кольца возвращаются через 100 мс, отображения исчезают с
   адресным пространством. Ограничение железа (без IOMMU): устройство с DMA может писать в любую память, этого программно не убрать. */

void    kdrv_poll(void);                                  /* основной цикл ядра: первое сканирование /drv, отложенное освобождение */
void    kdrv_proc_gone(uint32_t slot, uint32_t pid);      /* proc.c, при гибели процесса-драйвера (прерывания выключены, спать нельзя) */
int64_t kdrv_sys(unsigned nr, uint64_t a1, uint64_t a2, uint64_t a3);   /* syscall.c: вызовы KDRV_SYS_* */
void    kdrv_request_rescan(void);                        /* fsrv.c: установлен пакет - основной цикл просмотрит /drv ещё раз */
enum { KDRV_CTL_START = 1, KDRV_CTL_STOP = 2 };
int     kdrv_ctl_request(int op, const char* name);      /* fsrv.c: окно «Драйверы» просит запустить/остановить драйвер; 0 - принято в очередь (основной цикл исполняет), -1 - очередь занята */
void    kdrv_cmd(const char* arg);                        /* консоль: drv [start ИМЯ [арг] | stop ИМЯ | rescan] */

int kdrv_app_sig_check(const char* path, const void* image, size_t len, int* missing);

#endif
